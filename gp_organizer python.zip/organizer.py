import sys
import os
import pickle
import hashlib

input_index = ""
input_name = ""
input_extension = ""
input_ctime = ""
input_mtime = ""
input_atime = ""
input_intresflag = ""
input_attributes = ""

class gpFile:
    def __init__(self, index, name, extension, interested, attributes=""):  # ignored: created, modified, accessed
        self.index = index
        self.name = name
        self.extension = extension
        # self.created=created
        # self.modified=modified
        # self.accessed=accessed
        self.interested = interested
        self.attributes = attributes



def menu():
    global input_index, input_name, input_extension, input_ctime, input_mtime, input_atime, input_intresflag, input_attributes
    os.system('clear')
    while True:
        menu_string="Please select an option:\n" \
                "1 - set index ("+str(input_index)+")\n" \
                "2 - set name ("+str(input_name)+")\n" \
                "3 - set extension ("+str(input_extension)+")\n" \
                "4 - set created time* ("+str(input_ctime)+")\n" \
                "5 - set modified time* ("+str(input_mtime)+")\n" \
                "6 - set accessed time* ("+str(input_atime)+")\n" \
                "7 - set interested flag ("+str(input_intresflag)+")\n" \
                "8 - set attributes* \n" \
                "9 - clear options\n" \
                "10- run query! \n" \
                "11- exit!\n" \
                "> "
        try:
            command = int(input(menu_string))
        except ValueError:
            print("*** ERROR ***\nenter a valid command")
            continue

        if command== 1:
            print ("\nSet index: ")
            input_index= input()
        elif command == 2 :
            print("\nSet name: ")
            input_name = input()
        elif command == 3 :
            print("\nSet extension: ")
            input_extension = input()
        elif command == 4 :
            print("\nSet created time: ")
            input_ctime = input()
        elif command == 5 :
            print("\nSet modified time: ")
            input_mtime = input()
        elif command == 6 :
            print("\nSet accessed time: ")
            input_atime = input()
        elif command == 7 :
            print("\nSet interested flag: (True/False) ")
            input_intresflag = input()
        elif command == 8 :
            print("\nSet attributes: ")
            input_attributes = input()
        elif command == 9 :
            print("\n Options cleared!")
            input_index = ""
            input_name = ""
            input_extension = ""
            input_ctime = ""
            input_mtime = ""
            input_atime = ""
            input_intresflag = ""
        elif command == 10 :
            run()
        elif command == 11:
            print ("bye!")
            sys.exit(-1)
        else:
            print("*** ERROR ***\nenter a valid command")



def objectify():
    global files
    # -------------- objectifying gp files --------------
    for f in os.listdir(path):
        file_name, f_ext = os.path.splitext(f)
        if not (".gp" in f_ext): continue
        f_index, f_title = file_name.split(" ", 1)
        try:
            f_name, f_attribute = f_title.split(" ", 1)
        except ValueError:
            f_name = str(f_title.split(" ")).strip('[\']')
            f_attribute = " "
        f_interested = True if "##" in f_name else False

        files.append(gpFile(f_index, f_name, f_ext, f_interested, f_attribute))
        print("objectification complete")
    # -------------- dumping --------------
    f = open("bin/data", "wb")
    for i in range(len(files)):
        pickle.dump(files[i], f)



def run():
   # global input_index, input_name, input_extension, input_ctime, input_mtime, input_atime, input_interesflag, input_attributes, dump_is_valid
    global files
    if (dump_is_valid):
        # -------------- loading --------------
        f = open("bin/data", "rb")
        files = list()
        while True:
            try:
                files.append(pickle.load(f))
            except EOFError:
                break

    star= not((input_name) or (input_intresflag) or (input_atime) or (input_mtime) or (input_ctime) or (input_extension) or (input_index) or (input_attributes))
    os.system('clear')
    if star:
        print('\x1b[6;30;42m'+"Index"+ "\t" + "File Name" + "\t" + "File Type" + "\t" + "Is Interesting?"+ "\t"+ "attributes"'\x1b[0m')
        for i in range(len(files)):
            print(files[i].index + "\t" + files[i].name + "\t" + files[i].extension + "\t" + str(files[i].interested)+"\t" +files[i].attributes)
        input()
        return
    else:
        print('\x1b[6;30;42m' + "Index" + "\t" + "File Name" + "\t" + "File Type" + "\t" + "attributes" + "\t" + "Is Interesting?" + '\x1b[0m')
        if (input_attributes):
            for i in range(len(files)):
                att_flag = True if files[i].attributes.find(input_attributes) else False
                if (input_name==files[i].name or not(input_name)) and (input_intresflag==files[i].interested or not(input_intresflag)) and (input_extension==files[i].extension or not(input_extension)) and (input_index==files[i].index or not(input_index) and (att_flag)):
                    print(files[i].index + "\t" + files[i].name + "\t" + files[i].extension + "\t" + str(files[i].interested) + "\t" + files[i].attributes)
        else:
            for i in range(len(files)):
                if (input_name==files[i].name or not(input_name)) and (input_intresflag==files[i].interested or not(input_intresflag)) and (input_extension==files[i].extension or not(input_extension)) and (input_index==files[i].index or not(input_index)):
                    print(files[i].index + "\t" + files[i].name + "\t" + files[i].extension + "\t" + str(files[i].interested) + "\t" + files[i].attributes)


# -------------- checks gp files --------------
path = str(sys.argv[1])
dump_is_valid= False
# path = "../files"

files = list()

if  not os.path.exists(path):
    print ("*** ERROR ***\n path doesn't exist")
    input("\nPress enter to exit.")
    sys.exit(-1)

# -------------- generate checksum --------------
checksum=str(os.listdir(path))
checksum = hashlib.md5(checksum.encode('utf-8')).hexdigest()
if os.path.exists("bin/checksum"):
    f = open("bin/checksum", 'r')
    checkedsum = f.read()
    f.close()
    if checkedsum==checksum:
        dump_is_valid = True
        menu()
    else :
        objectify()
        menu()
else:
    f = open("bin/checksum", 'w')
    f.write(checksum)
    f.close()
    objectify()
    menu()


